# Bug Tracker for WordPress – hand-off package

A WordPress plugin where **WordPress is only the backend** (REST API, database, authentication) and the **entire UI is a React app** served on its own front-end URL (`/bug-tracker/`). Version **1.1.0**.

## What is in this zip

| Path | What it is |
|---|---|
| `START-HERE.md` | This file – migration + setup + test instructions |
| `CHAT_SUMMARY.md` | Summary of the whole build conversation: requirements, decisions, bugs found, what was verified |
| `project/` | Clean source tree (git-tracked files only, no `node_modules`). **This is what you copy into your new repo** |
| `bug-tracker-full-history.bundle` | The complete git history (7 commits) as a git bundle – use it if you want to keep history |
| `plugin/bug-tracker-1.1.0.zip` | Ready-to-install WordPress plugin zip (PHP + compiled React) |
| `dev-tools/` | The scripts used to test against a real WordPress (API tests + Playwright browser tests) – reference material, see below |
| `screenshots/` | A few screenshots of the finished UI |

---

## 1. Migrating to another git folder

### Option A – keep the full history (recommended)
```bash
git clone bug-tracker-full-history.bundle my-new-folder
cd my-new-folder
git checkout claude/kind-fermi-7wdnux      # the working branch in the bundle
git branch -M main                          # optional: rename to main
git remote remove origin                    # the bundle is not a real remote
git remote add origin <your-new-remote-url>
git push -u origin main
```

### Option B – fresh repository (no history)
```bash
mkdir my-new-folder && cd my-new-folder
git init -b main
cp -R /path/to/unzipped/project/. .         # note the trailing "/." so dotfiles (.gitignore) are copied
git add -A
git commit -m "Import Bug Tracker plugin v1.1.0"
git remote add origin <your-new-remote-url>
git push -u origin main
```

### What the repository layout looks like
```
.gitignore
README.md                 technical README (architecture, security model, REST API)
dist/bug-tracker.zip      committed installable build
bug-tracker/              <- the plugin itself (this folder is what WordPress installs)
├── bug-tracker.php       plugin header + bootstrap
├── uninstall.php
├── readme.txt
├── includes/             PHP: database, permissions, users, license, REST controllers, app page
├── admin/                wp-admin menu + "Settings & tools" screen
├── src/                  React + TypeScript source
├── build/                compiled app.js / app.css (committed so the plugin installs as-is)
└── package.json, vite.config.ts, tailwind.config.js, tsconfig.json, postcss.config.js
```
Nothing outside `bug-tracker/` is needed at runtime. If you move the plugin into an existing repo, copy just that folder (and `dist/` if you want the zip).

---

## 2. Build the React app (only needed if you change `src/`)

Requirements: **Node 20+** (developed on Node 22) and npm.

```bash
cd bug-tracker
npm install
npm run build        # type-check + production build -> build/app.js + build/app.css
npm run package      # build + create ../dist/bug-tracker.zip (needs the `zip` CLI)
npm run dev          # vite build --watch while developing
```
`build/` is committed, so **you do not need Node on the WordPress server** – only on the machine where you edit the UI. Always rebuild and commit `build/` after changing anything in `src/`.

The bundle is ~1 MB (≈290 KB gzipped, mostly Recharts). If that matters, code-split the charts.

---

## 3. Install on WordPress

Requirements: **WordPress 5.9+**, **PHP 7.4+**, MySQL/MariaDB. (Developed/tested on WordPress 7.1.2, PHP 8.3, MariaDB 10.11.)

1. WordPress admin → **Plugins → Add New → Upload Plugin** → choose `plugin/bug-tracker-1.1.0.zip` → Install → **Activate**.
   (Or copy the `bug-tracker/` folder to `wp-content/plugins/`.)
2. Activation creates the database tables (`{prefix}bug_tracker_*`) and a protected upload folder `wp-content/uploads/bug-tracker/`.
3. **First-run setup:** the site administrator who activates the plugin automatically becomes the **Bug Tracker Admin**.
   If nobody is assigned (e.g. WP-CLI activation, or an upgraded site) the app shows *"setup required"* and wp-admin shows a notice. Fix it at
   **wp-admin → Bug Tracker → Settings & tools → Bug Tracker Admin** (site administrators only).
4. Open the app at **`https://your-site.com/bug-tracker/`** (or `https://your-site.com/?bug_tracker_app=1` with plain permalinks). Visitors who are not logged in are redirected to the normal WordPress login and returned to the app.
5. If `/bug-tracker/` shows a 404, go to **Settings → Permalinks** and click *Save* once to flush rewrite rules.
6. In the app: **Users** → add people and assign them to projects; **Projects** → create projects; **Settings** → statuses, priorities, notifications, *Appearance*.
7. Want sample data? **wp-admin → Bug Tracker → Settings & tools → Demo data** generates users/projects/bugs/comments (and removes exactly what it created).

### Upgrading from 1.0.0
Just install the new zip over the old one. The first request runs an **automatic, idempotent, non-destructive migration**: it creates the new `bug_tracker_users` table, converts the old role-based users into tracker users (permissions derived from their old capabilities, effective project access preserved, leads/creators made explicit) and then waits for a site administrator to **assign the Bug Tracker Admin**. Existing projects, bugs, comments, attachments and history are untouched.
The old WordPress roles (`bug_tracker_manager`, `bug_tracker_contributor`) are left in the database but are **no longer used**.

### Uninstall
Deleting the plugin keeps your data **unless** *Settings → Projects → “Delete all data when the plugin is uninstalled”* is on (then tables, options, user meta and uploaded files are removed).

---

## 4. How access control works (important – it is custom)

* **WordPress roles/capabilities are not used.** WordPress only authenticates. Access lives in the plugin's `bug_tracker_users` table.
* One **Bug Tracker Admin** (assigned by a site administrator) – the only person who can use the Users screen / `/tracker-users/*` API, change settings, assign project access, run demo-data tools.
* Everyone else is *active* / *inactive* / *removed* with per-user flags: `create_bug`, `edit_bug`, `delete_bug`, `manage_projects`.
* **Project access is strictly by explicit assignment** (`project_members`). Hidden projects/bugs return **404**.
* **Licence seam:** `includes/class-license.php`. Default plan table: Free = 10 active users, Pro = 50, Unlimited = 0 (=no limit). Change/replace via filters: `bug_tracker_license_plans`, `bug_tracker_license_provider`, `bug_tracker_max_active_users`. No payment code exists.
* Other filter: `bug_tracker_app_slug` (default `bug-tracker`).

Data stored by the plugin:

| Kind | Names |
|---|---|
| Tables | `projects`, `project_members`, `bugs`, `comments`, `attachments`, `activity`, `notifications`, `users` (all `{$wpdb->prefix}bug_tracker_*`) |
| Options | `bug_tracker_settings`, `bug_tracker_db_version`, `bug_tracker_admin_user_id`, `bug_tracker_users_migrated`, `bug_tracker_license`, `bug_tracker_demo` |
| User meta | `bug_tracker_favorite_projects` (starred projects) |
| Files | `wp-content/uploads/bug-tracker/` (served only through an authenticated REST endpoint) |

---

## 5. Re-creating the test environment (optional but recommended)

All automated testing was done against a **real WordPress + MariaDB**, not mocks. The scripts are in `dev-tools/` – they contain placeholder paths (`/path/to/wordpress`, `/path/to/scratch`) you must edit.

```bash
# 1. WordPress core (any method works; this one needs only Composer)
mkdir wpbuild && cd wpbuild && composer require johnpbloch/wordpress-core
#    -> wpbuild/vendor/johnpbloch/wordpress-core is your WordPress root

# 2. Database
sudo apt-get install -y mariadb-server       # then start it (mysqld_safe)
mysql -uroot -e "CREATE DATABASE wp; CREATE USER 'wp'@'localhost' IDENTIFIED BY 'wp'; GRANT ALL ON wp.* TO 'wp'@'localhost';"

# 3. wp-config.php: copy wp-config-sample.php, set DB wp/wp/wp, and add
#    define('WP_DEBUG', true); define('WP_DEBUG_DISPLAY', false); define('WP_DEBUG_LOG', '/path/to/scratch/debug.log');
#    define('WP_HOME','http://127.0.0.1:8080'); define('WP_SITEURL','http://127.0.0.1:8080');

# 4. Install WordPress, symlink the plugin, create users, activate
php dev-tools/api-tests/install.php          # wp_install(): admin / adminpass
ln -s /path/to/repo/bug-tracker /path/to/wordpress/wp-content/plugins/bug-tracker
php dev-tools/api-tests/mkusers.php          # alice, bob, carol, sub (password: pass123)
php dev-tools/api-tests/activate.php

# 5. Serve (router.php gives pretty-permalink behaviour on PHP's built-in server)
cd /path/to/wordpress && php -S 127.0.0.1:8080 /path/to/router.php
```

Run order used during development (each script resets data first via `reset.sh`):
```bash
python3 test1.py   # core API: CRUD, filters, attachments, notifications, permissions, injection attempts
python3 test2.py   # demo data, favourites, UI settings
python3 test3.py   # user management: setup flow, authorisation, project isolation, licence, removal/history
node ui2.mjs; node ui3.mjs; node ui4.mjs; node ui5.mjs; node ui6.mjs   # Playwright browser flows (npm i playwright-core; uses /opt/pw-browsers chromium path – edit it)
node ovf.mjs       # checks nothing scrolls sideways at 390px
```
Expected: every script prints `FAILS: []` / only `PASS` lines. Last full run: backend 134 + 29 + 122 checks, plus all browser flows green, no PHP notices (the only Gravatar errors in the browser are due to the sandbox having no internet).
Test accounts: `admin/adminpass` (site admin, assigned Bug Tracker Admin by the tests), `alice/bob/carol/sub` with `pass123`.

---

## 6. Gotchas worth knowing
* **Tailwind preflight is disabled** and everything is scoped under `#bug-tracker-root`; `postcss.config.js` re-scopes Tailwind's `--tw-*` defaults. Don't "fix" this by enabling preflight.
* Radix portals (dialogs, menus, selects) render **inside `#bug-tracker-root`** (see `components/ui/portal.ts`) so scoped styles apply – keep that when adding new Radix components.
* REST auth is WordPress cookie auth + `X-WP-Nonce`. The server returns a fresh nonce in the `X-BT-Nonce` header; the client picks it up so long-lived tabs keep working.
* The UI is a hash-routed SPA (`/bug-tracker/#/bugs/12`); only `/bug-tracker/` needs a rewrite rule.
* Opening a bug always refetches it (and its comments/activity) – by design.
* Keyboard shortcuts: **C** new bug, **/** focus search.
* Times are stored in UTC; reports group by the site's timezone offset.

## 7. Ideas for next steps
* Paid licence add-on implementing `BT_License_Provider` (key validation, expiry) – no change needed in user management.
* Code-split Recharts / lazy-load pages to shrink the bundle.
* Move attachments outside the web root / support remote storage; virus-scan hook.
* Multisite support (per-site tables are already prefixed; user creation currently targets single-site).
* i18n: PHP strings use the `bug-tracker` text domain; the React UI strings are English-only.
* CI: run the Python API tests and Playwright flows in GitHub Actions with a WordPress service container.
* Comment editing, @mention autocomplete, saved filters, labels/tags as first-class objects.
