# dev-tools – reference test scripts

These are the scripts used to verify the plugin against a real WordPress. They are **not** part of the plugin and are not installed.
They contain placeholder paths you must edit: `/path/to/wordpress` (WordPress root), `/path/to/scratch` (a scratch dir for debug.log etc.), `/tmp/bt-…` (temp files), and Playwright's Chromium path (`/opt/pw-browsers/chromium-1194/chrome-linux/chrome`).
See `START-HERE.md` §5 for how to build the environment and the run order. Assumptions baked into the scripts: site at `http://127.0.0.1:8080`, DB `wp` (root, socket), users `admin/adminpass` and `alice, bob, carol, sub / pass123`.

* `api-tests/` – `t.py` (tiny cookie-session REST client), `test1.py` core API, `test2.py` demo/favourites/UI settings, `test3.py` user management, `seed.py` sample data, `reset.sh` data reset between runs, `router.php` + `up.sh` server helpers, `install.php`/`activate.php`/`mkusers.php`/`lifecycle.php`/`act2.php` WordPress bootstrap helpers.
* `browser-tests/` – Playwright (`playwright-core`) flows `ui1`–`ui6`, `ovf.mjs` (mobile overflow), `shots.mjs`/`fin.mjs`/`dlg.mjs` (screenshots).
