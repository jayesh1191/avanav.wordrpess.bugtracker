import { chromium } from 'playwright-core';
const BASE='http://127.0.0.1:8080';
const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome', args:['--no-sandbox'] });
const ctx = await browser.newContext({ viewport: { width: 1400, height: 900 } });
const page = await ctx.newPage();
const errors=[];
page.on('console', m => { if (['error','warning'].includes(m.type())) errors.push(m.type()+': '+m.text()); });
page.on('pageerror', e => errors.push('pageerror: '+e.message));
page.on('requestfailed', r => { if(!/gravatar|wp-includes|wp-admin\/(js|load)/.test(r.url())) errors.push('reqfailed: '+r.url()); });
page.on('response', r => { if (r.status()>=400 && !r.url().includes('gravatar') && r.status()!==200) errors.push('HTTP '+r.status()+' '+r.url()); });
await page.goto(BASE+'/wp-login.php');
await page.fill('#user_login','admin'); await page.fill('#user_pass','adminpass'); await page.click('#wp-submit');
errors.length=0;
await page.goto(BASE+'/bug-tracker/');
await page.waitForSelector('text=Dashboard', {timeout:15000});
await page.waitForSelector('text=Recent bugs');
await page.waitForTimeout(800);
await page.screenshot({ path: 'dash.png' });
const out=[];
for (const [name,hash,sel] of [['bugs','#/bugs','text=Login button unresponsive'],['projects','#/projects','text=Website Redesign'],['users','#/users','text=Alice'],['reports','#/reports','text=Bugs by status'],['notifications','#/notifications','text=You were assigned'],['settings','#/settings','text=Bug statuses'],['bug','#/bugs/1','text=Steps to reproduce'],['newbug','#/bugs/new','text=Report a bug'],['project','#/projects/1','text=Members']]) {
  await page.goto(BASE+'/bug-tracker/'+hash);
  await page.waitForSelector(sel,{timeout:10000}).catch(()=>out.push('MISSING '+name));
  await page.waitForTimeout(700);
  await page.screenshot({ path: name+'.png' });
}
console.log('missing:',out);
console.log('errors:',JSON.stringify(errors,null,1));
await browser.close();
