import { chromium } from 'playwright-core';
import fs from 'fs';
const BASE='http://127.0.0.1:8080';
const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome', args:['--no-sandbox'] });
const ctx = await browser.newContext({ viewport: { width: 1400, height: 900 } });
const page = await ctx.newPage();
const errors=[]; const results=[];
const ok=(n,c,x='')=>{results.push((c?'PASS ':'FAIL ')+n+(c?'':' '+x)); };
page.on('console', m => { if (m.type()==='error' && !/ERR_TUNNEL/.test(m.text())) errors.push(m.text()); });
page.on('pageerror', e => errors.push('pageerror: '+e.message));
page.on('response', r => { if (r.status()>=400 && !/gravatar/.test(r.url())) errors.push('HTTP '+r.status()+' '+r.url().slice(0,150)); });
await page.goto(BASE+'/wp-login.php'); await page.fill('#user_login','admin'); await page.fill('#user_pass','adminpass'); await page.click('#wp-submit');
await page.goto(BASE+'/bug-tracker/#/bugs/new');
await page.waitForSelector('#title');
// validation
await page.click('button:has-text("Create bug")');
ok('zod title error shown', await page.locator('text=Title must be at least 3 characters').isVisible());
ok('zod project error shown', await page.locator('text=Select a project').first().isVisible());
// fill
await page.fill('#title','Playwright created bug');
await page.fill('#description','Made through the UI');
await page.fill('#steps','1. a\n2. b');
await page.click('#project'); await page.click('[role=option]:has-text("Website Redesign")');
await page.click('#priority'); await page.click('[role=option]:has-text("Critical")');
await page.click('#assignee'); await page.click('[role=option]:has-text("Bob")');
await page.fill('#component','Auth'); await page.fill('#version','1.2.3'); await page.fill('#due','2030-05-01');
await page.setInputFiles('input[type=file]', ['note.txt']);
ok('file listed', await page.locator('text=note.txt').isVisible());
await page.click('button:has-text("Create bug")');
await page.waitForSelector('text=Made through the UI',{timeout:10000});
ok('redirected to detail', /#\/bugs\/11/.test(page.url()), page.url());
await page.waitForSelector('a:has-text("note.txt")');
ok('attachment shown', true);
ok('priority shows critical', (await page.locator('button[aria-label=Priority]').innerText()).includes('Critical'));
// inline status change
await page.click('button[aria-label=Status]'); await page.click('[role=option]:has-text("In Progress")');
await page.waitForSelector('text=Updated >> nth=0');
await page.waitForFunction(()=>document.querySelector('button[aria-label=Status]')?.textContent.includes('In Progress')); ok('inline status updated', true);
// comment
await page.fill('textarea[aria-label=Comment]','Comment from UI @alice');
await page.click('button[type=submit]:has-text("Comment")');
await page.waitForSelector('text=Comment from UI');
ok('comment count updates', await page.locator('text=1 comment').isVisible());
// activity
await page.waitForSelector('text=changed status');
ok('activity shows status change', true);
await page.screenshot({path:'detail2.png'});
// edit form
await page.goto(BASE+'/bug-tracker/#/bugs/11/edit');
await page.waitForSelector('#title');
ok('edit prefilled', (await page.inputValue('#title'))==='Playwright created bug');
await page.fill('#title','Playwright edited bug');
await page.click('button:has-text("Save changes")');
await page.waitForSelector('h1:has-text("Playwright edited bug")');
ok('edit saved', true);
// bugs list: search, bulk
await page.goto(BASE+'/bug-tracker/#/bugs');
await page.waitForSelector('text=Playwright edited bug');
await page.fill('input[aria-label="Search bugs"]','Playwright'); await page.waitForTimeout(900);
ok('search filters', (await page.locator('[role=row]').count())===2, await page.locator('[role=row]').count());
ok('url keeps search', page.url().includes('search=Playwright'));
await page.locator('[role=row] button[role=checkbox]').nth(1).click();
ok('bulk bar visible', await page.locator('text=1 selected').isVisible());
await page.click('button[aria-label="Bulk set status"]'); await page.click('[role=option]:has-text("Resolved")');
await page.waitForSelector('text=1 bug updated');
await page.waitForTimeout(500);
ok('bulk status applied', (await page.locator('[role=row]').nth(1).innerText()).includes('Resolved'));
// sorting
await page.fill('input[aria-label="Search bugs"]',''); await page.waitForTimeout(900);
await page.click('button[aria-sort]:has-text("Title")'); await page.waitForTimeout(500);
ok('sort in url', page.url().includes('orderby=title'));
// export
const [dl] = await Promise.all([page.waitForEvent('download'), page.click('button[aria-label="Export CSV"]')]);
const p = await dl.path(); const csv = fs.readFileSync(p,'utf8');
ok('csv export', csv.includes('Playwright edited bug') && csv.split('\r\n').length>=12, csv.slice(0,100));
// row delete via menu
await page.fill('input[aria-label="Search bugs"]','Playwright'); await page.waitForTimeout(900);
await page.locator('[role=row]').nth(1).hover(); await page.click('button[aria-label^="Actions for"]'); await page.click('[role=menuitem]:has-text("Delete")');
await page.click('[role=dialog] button:has-text("Delete")');
await page.waitForSelector('text=No bugs match these filters',{timeout:8000});
ok('row delete works', true);
// projects: create via dialog
await page.goto(BASE+'/bug-tracker/#/projects');
await page.waitForSelector('text=Website Redesign');
await page.click('button:has-text("New project")');
await page.click('button:has-text("Create project")');
ok('project validation', await page.locator('text=Name must be at least 2 characters').isVisible());
await page.fill('#p-name','Playwright Project'); await page.click('button:has-text("Create project")');
await page.waitForSelector('text=Project created');
await page.waitForSelector('main a:has-text("Playwright Project")');
await page.click('main a:has-text("Playwright Project")');
await page.waitForSelector('text=No bugs in this project');
await page.click('button[role=tab]:has-text("Members")');
await page.click('button:has-text("Delete")'); await page.click('[role=dialog] button:has-text("Delete project")');
await page.waitForSelector('text=Project deleted');
ok('project CRUD', true);
// settings save
await page.goto(BASE+'/bug-tracker/#/settings');
await page.waitForSelector('text=Bug statuses');
await page.click('button:has-text("Add")');
await page.locator('input[aria-label=Label]').last().fill('In QA');
await page.click('button:has-text("Save settings")');
await page.waitForSelector('text=Settings saved');
ok('role-permission tab removed (users managed on Users screen)', await page.locator('button[role=tab]:has-text("User permissions")').count()===0);
// dark mode + mobile
await page.goto(BASE+'/bug-tracker/#/');
await page.waitForSelector('text=Recent bugs');
await page.click('button[aria-label="Toggle dark mode"]'); await page.waitForTimeout(2000);
ok('dark class applied', await page.evaluate(()=>document.getElementById('bug-tracker-root').classList.contains('bt-dark')));
await page.screenshot({path:'dark.png'});
await page.setViewportSize({width:390,height:844}); await page.waitForTimeout(500);
await page.screenshot({path:'mobile.png'});
ok('no horizontal page scroll (mobile)', await page.evaluate(()=>document.documentElement.scrollWidth<=window.innerWidth+1), await page.evaluate(()=>document.documentElement.scrollWidth));
await page.click('button[aria-label="Open menu"]'); await page.waitForTimeout(400);
await page.screenshot({path:'mobile-menu.png'});
await page.click('nav[aria-label] >> text=Bugs, aside a:has-text("Bugs")').catch(()=>{});
await page.goto(BASE+'/bug-tracker/#/bugs'); await page.waitForTimeout(1200);
await page.screenshot({path:'mobile-bugs.png'});
ok('no horizontal page scroll (mobile bugs)', await page.evaluate(()=>document.documentElement.scrollWidth<=window.innerWidth+1), await page.evaluate(()=>document.documentElement.scrollWidth));
console.log(results.join('\n')); console.log('ERRORS:',JSON.stringify(errors,null,1));
await browser.close();
