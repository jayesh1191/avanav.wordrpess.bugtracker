import { chromium } from 'playwright-core';
const BASE='http://127.0.0.1:8080';
const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome', args:['--no-sandbox'] });
const errors=[]; const res=[]; const ok=(n,c,x='')=>res.push((c?'PASS ':'FAIL ')+n+(c?'':' '+x));
async function login(u,p,w=1400,h=860){ const ctx=await b.newContext({viewport:{width:w,height:h}}); const page=await ctx.newPage();
  page.on('console', m => { if (m.type()==='error' && !/ERR_TUNNEL|404|403|409|400/.test(m.text())) errors.push(u+': '+m.text()); });
  page.on('pageerror', e => errors.push(u+' pageerror: '+e.message));
  await page.goto(BASE+'/wp-login.php'); await page.fill('#user_login',u); await page.fill('#user_pass',p); await page.click('#wp-submit'); return page; }
const p = await login('admin','adminpass');
await p.goto(BASE+'/bug-tracker/#/users'); await p.waitForSelector('[role=listitem]');
const rows = await p.locator('[role=listitem]').count(); ok('accordion rows listed', rows>=4, rows);
const bob = p.locator('[role=listitem]:has-text("Bob")').first();
const txt = await bob.innerText();
ok('collapsed row shows name, email, status, project count', /Bob/.test(txt) && /bob@example.com/.test(txt) && /Active/.test(txt) && /2\s*projects/.test(txt), txt.replace(/\n/g,' | '));
ok('collapsed row has actions', await bob.locator('button[aria-label="Actions for Bob"]').count()===1);
ok('panel hidden when collapsed', await p.locator('[role=region][aria-label^="Details for"]').count()===0);
await bob.locator('button[aria-controls]').click(); await p.waitForSelector('[role=region][aria-label="Details for Bob"]');
ok('expanded shows details + permissions + projects', await p.locator('text=Project access').first().isVisible() && await p.locator('text=Permissions').first().isVisible() && await p.locator('li:has-text("Website Redesign"):has-text("Has access")').count()>=1);
await p.screenshot({path:'u-expanded.png'});
// revoke then assign project access
await p.click('button[aria-label="Remove Bob from Mobile App"]'); await p.waitForSelector('li:has-text("Mobile App"):has-text("No access")');
ok('revoke project access in UI', await bob.innerText().then(t=>/1\s*project\b/.test(t)));
await p.click('button[aria-label="Assign Bob to Mobile App"]'); await p.waitForSelector('li:has-text("Mobile App"):has-text("Has access")'); ok('assign project access in UI', true);
// permissions
await p.locator('[role=region] label:has-text("Delete bugs") button[role=checkbox]').click();
await p.click('button:has-text("Save permissions")'); await p.waitForSelector('text=Permissions saved'); ok('permissions saved', true);
// deactivate / activate
await p.click('[role=region] button:has-text("Deactivate")'); await p.waitForSelector('text=Bob deactivated');
await p.waitForFunction(()=>[...document.querySelectorAll('[role=listitem]')].find(e=>e.textContent.includes('Bob'))?.textContent.includes('Inactive')); ok('deactivate shows Inactive', true);
await p.click('[role=region] button:has-text("Activate")'); await p.waitForSelector('text=Bob activated'); ok('activate again', true);
// edit dialog
await p.click('button[aria-label="Actions for Bob"]'); await p.click('[role=menuitem]:has-text("Edit details")');
await p.fill('#eu-name','Bobby'); await p.fill('#eu-email','not-an-email'); await p.click('[role=dialog] button:has-text("Save changes")');
ok('edit: zod email error', await p.locator('text=Enter a valid e-mail address').isVisible());
await p.fill('#eu-email','bob@example.com'); await p.click('[role=dialog] button:has-text("Save changes")'); await p.waitForSelector('text=User updated');
ok('edit saved', await p.locator('[role=listitem]:has-text("Bobby")').count()===1);
// admin row protected
const adm = p.locator('[role=listitem]:has-text("Admin")').first();
ok('admin row has no deactivate/remove', await adm.locator('button:has-text("Deactivate")').count()===0);
// add existing
await p.click('button:has-text("Add user")'); await p.waitForSelector('[role=dialog]');
await p.waitForSelector('[role=radio]'); ok('candidates listed (excludes members)', await p.locator('[role=dialog] [role=radio]:has-text("Sub")').count()===1 && await p.locator('[role=dialog] [role=radio]:has-text("Bobby")').count()===0);
await p.click('[role=dialog] [role=radio]:has-text("Sub")'); await p.locator('[role=dialog] li:has-text("Website Redesign") button[role=checkbox]').click();
await p.click('[role=dialog] button:has-text("Add user")'); await p.waitForSelector('text=Sub added'); ok('existing user added with project', await p.locator('[role=listitem]:has-text("Sub"):has-text("1 project")').count()===1);
// create new with validation
await p.click('button:has-text("Add user")'); await p.click('[role=tab]:has-text("Create new user")');
await p.click('[role=dialog] button:has-text("Create & add")');
ok('new user: validation errors', await p.locator('text=At least 3 characters').isVisible() && await p.locator('text=Enter a valid e-mail address').isVisible());
await p.fill('#nu-username','bob'); await p.fill('#nu-email','x@example.com'); await p.click('[role=dialog] button:has-text("Create & add")');
await p.waitForSelector('text=already taken'); ok('new user: server rejects duplicate username', true);
await p.fill('#nu-username','frank'); await p.fill('#nu-email','frank@example.com'); await p.fill('#nu-name','Frank Castle');
await p.locator('[role=dialog] label:has-text("E-mail them") button[role=checkbox]').click();
await p.click('[role=dialog] button:has-text("Create & add")'); await p.waitForSelector('text=Frank Castle added'); ok('new user created', await p.locator('[role=listitem]:has-text("Frank Castle")').count()===1);
// search + filter
await p.fill('input[aria-label="Search users"]','frank'); await p.waitForTimeout(700);
ok('search filters list', await p.locator('[role=listitem]').count()===1);
await p.fill('input[aria-label="Search users"]',''); await p.waitForTimeout(600);
// remove with confirm
await p.fill('input[aria-label="Search users"]','Frank'); await p.waitForTimeout(600);
await p.click('button[aria-label="Actions for Frank Castle"]'); await p.click('[role=menuitem]:has-text("Remove from Bug Tracker")');
ok('remove asks for confirmation', await p.locator('[role=dialog]:has-text("They lose access")').isVisible());
await p.click('[role=dialog] button:has-text("Remove")'); await p.waitForSelector('text=removed from the Bug Tracker');
await p.waitForTimeout(500); ok('removed user leaves default list', await p.locator('[role=listitem]:has-text("Frank")').count()===0);
await p.click('[role=tab]:has-text("Removed")'); await p.waitForSelector('[role=listitem]:has-text("Frank")'); ok('removed filter shows user w/ Restore', await p.locator('button:has-text("Restore")').count()>=1);
await p.click('button:has-text("Restore")'); await p.waitForSelector('text=restored'); ok('restore works', true);
await p.screenshot({path:'u-list.png'});
// license: header chip
ok('license chip visible', await p.locator('text=/\\d+ \\/ 10 active/').first().isVisible());
// non-admins
const c = await login('bob','pass123');
await c.goto(BASE+'/bug-tracker/#/users'); await c.waitForSelector('text=Alice');
ok('contributor sees read-only team (no accordion / add)', await c.locator('[role=listitem]').count()===0 && await c.locator('button:has-text("Add user")').count()===0);
ok('contributor sidebar says Team', await c.locator('aside >> text=Team').count()>=1);
const status = await c.evaluate(async()=>{ const r=await fetch(window.BugTrackerConfig.restUrl+'tracker-users',{headers:{'X-WP-Nonce':window.BugTrackerConfig.nonce}}); return r.status; });
ok('contributor direct REST call blocked', status===403, status);
// mobile
const m = await login('admin','adminpass',390,844);
await m.goto(BASE+'/bug-tracker/#/users'); await m.waitForSelector('[role=listitem]'); await m.waitForTimeout(500);
await m.locator('[role=listitem] button[aria-controls]').nth(1).click(); await m.waitForTimeout(300);
ok('mobile: no horizontal scroll', await m.evaluate(()=>document.documentElement.scrollWidth<=window.innerWidth+1), await m.evaluate(()=>document.documentElement.scrollWidth));
await m.screenshot({path:'u-mobile.png'});
console.log(res.join('\n')); console.log('ERRORS:',JSON.stringify(errors));
await b.close();
