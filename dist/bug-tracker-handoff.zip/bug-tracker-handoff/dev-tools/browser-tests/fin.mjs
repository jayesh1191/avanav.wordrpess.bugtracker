import { chromium } from 'playwright-core';
const BASE='http://127.0.0.1:8080';
const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome', args:['--no-sandbox'] });
const p = await (await b.newContext({viewport:{width:1400,height:800}})).newPage();
await p.goto(BASE+'/bug-tracker/'); console.log('unauth ->', p.url());
await p.fill('#user_login','admin'); await p.fill('#user_pass','adminpass'); await p.click('#wp-submit');
await p.waitForSelector('text=Recent bugs'); console.log('after login ->', p.url(), '| adminbar:', await p.locator('#wpadminbar').count());
await p.goto(BASE+'/wp-admin/admin.php?page=bug-tracker'); await p.waitForSelector('text=Recent bugs'); console.log('wp-admin menu ->', p.url());
await p.screenshot({path:'standalone.png'}); await b.close();
