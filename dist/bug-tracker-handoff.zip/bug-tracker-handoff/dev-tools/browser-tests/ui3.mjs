import { chromium } from 'playwright-core';
const BASE='http://127.0.0.1:8080';
const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome', args:['--no-sandbox'] });
const errors=[]; const res=[]; const ok=(n,c,x='')=>res.push((c?'PASS ':'FAIL ')+n+(c?'':' '+x));
async function login(u,p){ const ctx=await browser.newContext({viewport:{width:1400,height:900}}); const page=await ctx.newPage();
  page.on('console', m => { if (m.type()==='error' && !/ERR_TUNNEL/.test(m.text())) errors.push(u+': '+m.text()); });
  page.on('pageerror', e => errors.push(u+' pageerror: '+e.message));
  await page.goto(BASE+'/wp-login.php'); await page.fill('#user_login',u); await page.fill('#user_pass',p); await page.click('#wp-submit'); return page; }
// admin: create+delete bug from detail page, project delete
const a = await login('admin','adminpass');
await a.goto(BASE+'/bug-tracker/#/bugs/3'); await a.waitForSelector('text=Properties');
await a.click('button:has-text("Delete")'); await a.click('[role=dialog] button:has-text("Delete")');
await a.waitForSelector('text=Bug deleted'); await a.waitForTimeout(800);
ok('bug detail delete navigates to list', a.url().endsWith('#/bugs'), a.url());
// bob (contributor): sees assigned bugs, notifications, no settings nav, no new project button
const b = await login('bob','pass123');
await b.goto(BASE+'/bug-tracker/#/'); await b.waitForSelector('text=Recent bugs');
ok('contributor has no Settings link', await b.locator('aside a:has-text("Settings")').count()===0);
await b.goto(BASE+'/bug-tracker/#/projects'); await b.waitForSelector('text=Website Redesign');
ok('contributor has no New project button', await b.locator('button:has-text("New project")').count()===0);
await b.goto(BASE+'/bug-tracker/#/notifications'); await b.waitForSelector('text=You were assigned');
ok('bob sees assignment notification', true);
await b.click('button:has-text("You were assigned") >> nth=0'); await b.waitForSelector('text=Properties'); ok('notification opens bug', /#\/bugs\/\d+/.test(b.url()));
await b.goto(BASE+'/bug-tracker/#/settings'); await b.waitForTimeout(1200);
ok('settings route redirects/blocks for contributor', !(await b.locator('text=Bug statuses').count()), '');
await b.goto(BASE+'/bug-tracker/#/users'); await b.waitForSelector('text=Alice');
ok('contributor: no email column', await b.locator('th:has-text("Email")').count()===0);
await b.screenshot({path:'users-bob.png'});
// error state: server unreachable simulated by bad bug id
await b.goto(BASE+'/bug-tracker/#/bugs/9999'); await b.waitForSelector("text=Couldn't load this"); ok('error state for missing bug', true);
console.log(res.join('\n')); console.log('ERRORS:',JSON.stringify(errors.filter(e=>!/404|403/.test(e)),null,1));
await browser.close();
