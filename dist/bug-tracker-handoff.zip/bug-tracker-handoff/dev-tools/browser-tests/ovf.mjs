import { chromium } from 'playwright-core';
const BASE='http://127.0.0.1:8080';
const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome', args:['--no-sandbox'] });
const page = await (await browser.newContext({ viewport: { width: 390, height: 844 } })).newPage();
await page.goto(BASE+'/wp-login.php'); await page.fill('#user_login','admin'); await page.fill('#user_pass','adminpass'); await page.click('#wp-submit');
for (const h of ['#/','#/bugs','#/users','#/projects','#/reports','#/settings','#/bugs/1','#/bugs/new']) {
  await page.goto(BASE+'/bug-tracker/'+h); await page.waitForTimeout(1500);
  const r = await page.evaluate(()=>{
    const vw=window.innerWidth; const out=[];
    document.querySelectorAll('#bug-tracker-root *').forEach(e=>{const r=e.getBoundingClientRect(); if(r.right>vw+1 && r.width>0){ // not inside a scroll container
      let p=e.parentElement, scroll=false; while(p&&p.id!=='bug-tracker-root'){const o=getComputedStyle(p).overflowX; if(o==='auto'||o==='scroll'||o==='hidden'){scroll=true;break;} p=p.parentElement;}
      if(!scroll) out.push(e.tagName+'.'+String(e.className).slice(0,60)+' '+Math.round(r.right));}});
    return {sw:document.documentElement.scrollWidth, vw, out:out.slice(0,4)};
  });
  console.log(h, JSON.stringify(r));
}
await browser.close();
