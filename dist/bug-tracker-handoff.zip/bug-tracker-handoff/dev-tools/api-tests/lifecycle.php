<?php
require '/path/to/wordpress/wp-load.php';
require_once ABSPATH . 'wp-admin/includes/plugin.php';
global $wpdb;
$cnt = fn() => (int)$wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}bug_tracker_bugs");
echo "bugs before: ", $cnt(), "\n";
deactivate_plugins('bug-tracker/bug-tracker.php');
echo "deactivated: ", var_export(!is_plugin_active('bug-tracker/bug-tracker.php'), true), " bugs kept: ", $cnt(), "\n";
$r = activate_plugin('bug-tracker/bug-tracker.php');
echo "reactivated: ", is_wp_error($r) ? $r->get_error_message() : 'ok', " bugs: ", $cnt(), "\n";
// uninstall path with delete_data on
$s = get_option('bug_tracker_settings'); $s['uninstall']['delete_data'] = true; update_option('bug_tracker_settings', $s);
deactivate_plugins('bug-tracker/bug-tracker.php');
$r = uninstall_plugin('bug-tracker/bug-tracker.php');
$left = $wpdb->get_col("SHOW TABLES LIKE '{$wpdb->prefix}bug_tracker_%'");
echo "tables after uninstall: ", count($left), " option: ", var_export(get_option('bug_tracker_settings'), true), " role: ", var_export((bool)get_role('bug_tracker_manager'), true), "\n";
// clean install again
$r = activate_plugin('bug-tracker/bug-tracker.php');
$left = $wpdb->get_col("SHOW TABLES LIKE '{$wpdb->prefix}bug_tracker_%'");
echo "fresh activation tables: ", count($left), "\n";
