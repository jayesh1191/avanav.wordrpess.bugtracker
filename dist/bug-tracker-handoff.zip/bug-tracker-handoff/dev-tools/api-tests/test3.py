import sys,re,urllib.parse,json,subprocess; sys.path.insert(0,'.')
from t import *
def sql(q): return subprocess.run(['mysql','-uroot','wp','-N','-e',q],capture_output=True,text=True).stdout.strip()
admin=C('admin','adminpass'); alice=C('alice','pass123'); bob=C('bob','pass123'); carol=C('carol','pass123'); sub=C('sub','pass123')

# ---------- initial setup: no Bug Tracker Admin assigned yet
sql("delete from wp_options where option_name='bug_tracker_admin_user_id'")
st,body,_=admin.raw('GET',BASE+'/bug-tracker/'); 
check('setup: app locked for site admin until admin assigned',st==403 and b'Assign the Bug Tracker Admin' in body,st)
st,body,_=alice.raw('GET',BASE+'/bug-tracker/'); check('setup: others told to ask site admin',st==403 and b'site administrator' in body,st)
st,body,_=admin.raw('GET',BASE+'/wp-admin/'); check('setup: wp-admin notice shown to site admin',b'Bug Tracker setup required' in body)
# the site admin has no tracker access (WP admin role alone grants nothing)
admin.cfg=None
def get_nonce(c,action,url='/wp-admin/admin.php?page=bug-tracker-settings'):
    st,body,_=c.raw('GET',BASE+url); html=body.decode()
    m=re.search(r'name="_wpnonce" value="([^"]+)"[^>]*>(?:(?!</form>).)*?name="action"|name="action" value="'+action+'">\s*<input[^>]*name="_wpnonce" value="([^"]+)"',html,re.S)
    forms=html.split('<form')
    for f in forms:
        if f'value="{action}"' in f:
            return re.search(r'name="_wpnonce" value="([^"]+)"',f).group(1)
def post(c,action,fields):
    d={'action':action,**fields}
    return c.raw('POST',BASE+'/wp-admin/admin-post.php',urllib.parse.urlencode(d).encode(),{'Content-Type':'application/x-www-form-urlencoded'})
n=get_nonce(admin,'bug_tracker_set_admin')
st,_,hd=post(alice,'bug_tracker_set_admin',{'_wpnonce':n,'admin_user':'alice'}); check('non-site-admin cannot assign BT admin',st==403,st)
st,_,hd=post(admin,'bug_tracker_set_admin',{'_wpnonce':'bad','admin_user':'admin'}); check('bad nonce rejected',st==403,st)
st,_,hd=post(admin,'bug_tracker_set_admin',{'_wpnonce':n,'admin_user':'nobody-here'}); check('unknown user rejected',st==302 and 'admin_invalid' in hd.get('Location',''),hd.get('Location'))
check('still unassigned after failures',sql("select count(*) from wp_options where option_name='bug_tracker_admin_user_id'")=='0')
st,_,hd=post(admin,'bug_tracker_set_admin',{'_wpnonce':n,'admin_user':'admin'}); check('site admin assigns BT admin',st==302 and 'admin_set' in hd.get('Location',''),hd.get('Location'))
check('admin option stored',sql("select option_value from wp_options where option_name='bug_tracker_admin_user_id'")=='1')
subprocess.run(['python3','seed.py'],capture_output=True)
admin=C('admin','adminpass'); alice=C('alice','pass123'); bob=C('bob','pass123'); carol=C('carol','pass123')
check('BT admin has all perms in UI config',all(admin.cfg['user']['caps'].values()),admin.cfg['user']['caps'])
check('contributor lacks admin perms',bob.cfg['user']['caps']['manage_bug_tracker_users'] is False and bob.cfg['user']['caps']['view_bug_tracker'] is True)
check('alice (migrated manager) has manage_projects but not admin',alice.cfg['user']['caps']['manage_projects'] and not alice.cfg['user']['caps']['manage_bug_tracker_users'],alice.cfg['user']['caps'])

# ---------- WordPress roles are NOT used
sql("update wp_usermeta set meta_value='a:1:{s:13:\"administrator\";b:1;}' where user_id=4 and meta_key='wp_capabilities'")  # carol becomes a WP *administrator*
carol=C('carol','pass123'); st,js,_=carol.api('GET','users',params={'per_page':5}) if carol.cfg else (0,0,0)
check('WP administrator role gives no tracker rights (carol)',st in (0,403) or carol.cfg is None or not carol.cfg['user']['caps']['manage_bug_tracker_users'],carol.cfg and carol.cfg['user']['caps'])
st,js,_=carol.api('GET','tracker-users') if carol.cfg else (403,0,0); check('WP administrator cannot list tracker users',st==403,st)
sql("update wp_usermeta set meta_value='a:1:{s:10:\"subscriber\";b:1;}' where user_id=4 and meta_key='wp_capabilities'")
sql("update wp_usermeta set meta_value='a:1:{s:10:\"subscriber\";b:1;}' where user_id=2 and meta_key='wp_capabilities'")  # alice loses her WP role entirely
alice=C('alice','pass123'); st,js,_=alice.api('GET','bugs'); check('tracker access survives losing WP role (alice)',st==200,st)
sql("update wp_usermeta set meta_value='a:1:{s:21:\"bug_tracker_manager\";b:1;}' where user_id=2 and meta_key='wp_capabilities'")

# ---------- authorization: only the BT admin may touch user management (direct REST calls)
anon=C()
eps=[('GET','tracker-users',None),('GET','tracker-users/candidates',None),('GET','tracker-users/license',None),('POST','tracker-users',{'user_id':5}),('PUT','tracker-users/3',{'status':'inactive'}),('DELETE','tracker-users/3',None),('PUT','tracker-users/3/projects/1',{'granted':True})]
for who,c in [('contributor',bob),('manager-with-projects',alice)]:
    for m,p,b in eps:
        st,js,_=c.api(m,p,b); check(f'{who} blocked: {m} {p}',st==403,(st,js))
for m,p,b in eps:
    st,js,_=anon.api(m,p,b); check(f'anonymous blocked: {m} {p}',st in (401,403),st)
    st,js,_=admin.api(m,p,b) if False else (0,0,0)
st,js,_=bob.api('PUT','projects/1',{'members':[3]}); check('non-admin cannot change project members',st==403,(st,js))
st,js,_=alice.api('PUT','projects/1',{'lead_id':3}); check('manage_projects user cannot change project lead',st==403,(st,js))
# privilege escalation attempts through the settings endpoint / direct options
st,js,_=bob.api('PUT','settings',{'permissions':{'roles':[]}}); check('contributor cannot PUT settings',st==403)

# ---------- listing + accordion data
st,js,_=admin.api('GET','tracker-users'); check('admin lists tracker users',st==200 and js['total']>=4 and 'license' in js,(st,str(js)[:200]))
byname={u['login']:u for u in js['items']}
check('list shape',all(k in byname['bob'] for k in ('name','email','status','project_count','projects','permissions','is_admin')),byname.get('bob'))
check('bob has 2 projects',byname['bob']['project_count']==2,byname['bob'])
check('admin flagged',byname['admin']['is_admin'] is True and byname['bob']['is_admin'] is False)
check('sub (no WP role, never added) not listed','sub' not in byname)
st,js,_=admin.api('GET','tracker-users',params={'search':'ali'}); check('search',js['total']==1 and js['items'][0]['login']=='alice',js['total'])
st,js,_=admin.api('GET','tracker-users',params={'status':'inactive'}); check('status filter empty',js['total']==0)
st,js,_=admin.api('GET','tracker-users',params={'per_page':2,'page':2}); check('pagination',len(js['items'])==2 and js['total_pages']>=2,(len(js['items']),js['total_pages']))

# ---------- add existing user (+ no WP role assignment), duplicates, invalid input
role_before=sql("select meta_value from wp_usermeta where user_id=5 and meta_key='wp_capabilities'")
st,js,_=admin.api('GET','tracker-users/candidates'); check('candidates include sub',any(u['login']=='sub' for u in js) and not any(u['login']=='bob' for u in js),[u['login'] for u in js])
st,js,_=admin.api('POST','tracker-users',{'user_id':5,'permissions':['create_bug','nonsense'],'projects':[1,9999]}); check('add existing user',st==201 and js['permissions']==['create_bug'] and js['project_count']==1 and js['status']=='active',(st,js))
SUB=js['id']
check('WP role of added user untouched',sql("select meta_value from wp_usermeta where user_id=5 and meta_key='wp_capabilities'")==role_before)
st,js,_=admin.api('POST','tracker-users',{'user_id':5}); check('duplicate rejected (409)',st==409,(st,js))
st,js,_=admin.api('POST','tracker-users',{'user_id':99999}); check('invalid user rejected',st==400,(st,js))
st,js,_=admin.api('POST','tracker-users',{}); check('empty request rejected',st==400)
st,js,_=admin.api('POST','tracker-users',{'user_id':'abc; drop table'}); check('garbage id rejected',st==400)
# new user creation
st,js,_=admin.api('POST','tracker-users',{'new_user':{'username':'dana','email':'bad-email','display_name':'Dana'}}); check('new user: bad email rejected',st==400 and 'email' in js['data']['fields'],(st,js))
st,js,_=admin.api('POST','tracker-users',{'new_user':{'username':'bob','email':'x@example.com'}}); check('new user: taken username rejected',st==400 and 'username' in js['data']['fields'])
st,js,_=admin.api('POST','tracker-users',{'new_user':{'username':'dana2','email':'bob@example.com'}}); check('new user: taken email rejected',st==400 and 'email' in js['data']['fields'])
st,js,_=admin.api('POST','tracker-users',{'new_user':{'username':'dana','email':'dana@example.com','display_name':'Dana <b>X</b>'},'projects':[2]}); check('create brand-new user',st==201 and js['name']=='Dana X' and js['project_count']==1,(st,js))
DANA=js['id']; dana_wp=js['user_id']
check('new WP user has NO role',sql(f"select meta_value from wp_usermeta where user_id={dana_wp} and meta_key='wp_capabilities'") in ('a:0:{}',''),sql(f"select meta_value from wp_usermeta where user_id={dana_wp} and meta_key='wp_capabilities'"))

# ---------- edit / activate / deactivate
st,js,_=admin.api('PUT',f'tracker-users/{SUB}',{'permissions':['create_bug','edit_bug','delete_bug']}); check('edit permissions',js['permissions']==['create_bug','edit_bug','delete_bug'])
st,js,_=admin.api('PUT',f'tracker-users/{SUB}',{'display_name':'Sub Renamed','email':'sub.new@example.com'}); check('edit profile of normal user',st==200 and js['name']=='Sub Renamed' and js['email']=='sub.new@example.com',(st,js))
st,js,_=admin.api('PUT',f'tracker-users/{SUB}',{'email':'alice@example.com'}); check('edit: duplicate email rejected',st==400)
st,js,_=admin.api('PUT',f'tracker-users/{SUB}',{'email':'nope'}); check('edit: invalid email rejected',st==400)
st,js,_=admin.api('PUT','tracker-users/1',{'email':'evil@example.com'}); check('cannot edit WP-administrator profile (takeover guard)',st==403,(st,js))
st,js,_=admin.api('PUT','tracker-users/1',{'permissions':[]}); check('BT admin permissions immutable',st==409,st)
st,js,_=admin.api('PUT','tracker-users/1',{'status':'inactive'}); check('BT admin cannot be deactivated',st==409,st)
st,js,_=admin.api('DELETE','tracker-users/1'); check('BT admin cannot be removed',st==409,st)
st,js,_=admin.api('PUT','tracker-users/9999',{'status':'inactive'}); check('unknown tracker user 404',st==404)
st,js,_=admin.api('PUT',f'tracker-users/{SUB}',{'status':'weird'}); check('invalid status rejected',st==400)
# project access enforcement for the added user
sub=C('sub','pass123'); 
check('added user can open app',sub.cfg is not None and sub.cfg['user']['caps']['view_bug_tracker'])
st,js,_=sub.api('GET','projects'); check('user sees ONLY assigned projects',[p['id'] for p in js]==[1],[p['id'] for p in js])
st,js,_=sub.api('GET','projects/2'); check('direct URL to unassigned project -> 404',st==404,st)
st,js,_=sub.api('GET','bugs',params={'project_id':2}); check('filter by unassigned project returns nothing',js['total']==0)
st,js,_=sub.api('GET','bugs'); n1=js['total']; check('bug list scoped to assigned project',all(b['project']['id']==1 for b in js['items']) and n1>0,n1)
st,b2,_=admin.api('GET','bugs',params={'project_id':2,'per_page':1}); B2=b2['items'][0]['id']
for m,pth,body in [('GET',f'bugs/{B2}',None),('PUT',f'bugs/{B2}',{'title':'hacked'}),('DELETE',f'bugs/{B2}',None),('GET',f'bugs/{B2}/comments',None),('POST',f'bugs/{B2}/comments',{'content':'x'}),('GET',f'bugs/{B2}/activity',None)]:
    st,js,_=sub.api(m,pth,body); check(f'unassigned project bug blocked: {m} {pth.split("/",1)[1] if "/" in pth else ""}',st in (403,404),st)
st,js,_=sub.api('POST','bugs',{'title':'Sneaky','project_id':2}); check('cannot create bug in unassigned project',st==400,(st,js))
st,js,_=sub.api('POST','bugs/bulk',{'ids':[B2],'action':'priority','value':'low'}); check('bulk on unassigned project fails',st==200 and js['failed'] and not js['updated'],(st,js))
st,js,_=sub.api('GET','dashboard'); check('dashboard scoped',js['totals']['total']==n1,js['totals'])
st,js,_=sub.api('GET','reports'); check('reports scoped',sum(c['count'] for c in js['by_status'])==n1)
st,js,_=sub.api('GET','users'); check('users directory limited to collaborators (no emails)',all('email' not in u for u in js['items']) and {u['login'] for u in js['items']}<= {'admin','alice','bob','carol','sub'},[u['login'] for u in js['items']])
# bugs the user *reported/was assigned* in a project they are not assigned to are NOT visible any more
sql(f"update wp_bug_tracker_bugs set reporter_id=5, assignee_id=5 where id={B2}")
st,js,_=sub.api('GET',f'bugs/{B2}'); check('reporter/assignee alone gives no access to unassigned project',st==404,st)
sql(f"update wp_bug_tracker_bugs set reporter_id=1, assignee_id=0 where id={B2}")
# assigning/revoking access via API
st,js,_=admin.api('PUT',f'tracker-users/{SUB}/projects/2',{'granted':True,'role':'maintainer'}); check('grant project access',st==200 and js['project_count']==2,(st,js))
st,js,_=sub.api('GET',f'bugs/{B2}'); check('access effective immediately',st==200,st)
st,js,_=admin.api('PUT',f'tracker-users/{SUB}/projects/2',{'granted':False}); check('revoke project access',st==200 and js['project_count']==1)
st,js,_=sub.api('GET',f'bugs/{B2}'); check('revocation effective immediately',st==404,st)
st,js,_=admin.api('PUT',f'tracker-users/{SUB}/projects/9999',{'granted':True}); check('grant unknown project 404',st==404)
# deactivate / reactivate
st,js,_=admin.api('PUT',f'tracker-users/{SUB}',{'status':'inactive'}); check('deactivate user',js['status']=='inactive')
st,js,_=sub.api('GET','bugs'); check('inactive user blocked from API',st==403,st)
st,body,_=sub.raw('GET',BASE+'/bug-tracker/'); check('inactive user blocked from app page',st==403)
check('history preserved on deactivate',sql(f"select count(*) from wp_bug_tracker_comments where user_id=5")>='0' and sql("select count(*) from wp_bug_tracker_bugs")!='0')
st,js,_=admin.api('PUT',f'tracker-users/{SUB}',{'status':'active'}); check('reactivate user',js['status']=='active')
st,js,_=sub.api('GET','bugs'); check('reactivated user works again',st==200)

# ---------- removal preserves content / history
sub.api('POST','comments' if False else f'bugs/{n1 and 1}/comments',{'content':'comment by sub'})
sql("update wp_bug_tracker_bugs set assignee_id=5 where id=1")
before=sql("select (select count(*) from wp_bug_tracker_bugs),(select count(*) from wp_bug_tracker_comments),(select count(*) from wp_bug_tracker_activity)")
st,js,_=admin.api('DELETE',f'tracker-users/{SUB}'); check('remove user',st==200)
after=sql("select (select count(*) from wp_bug_tracker_bugs),(select count(*) from wp_bug_tracker_comments),(select count(*) from wp_bug_tracker_activity)")
bb,cb,ab=map(int,before.split()); ba,ca,aa=map(int,after.split())
check('bugs & comments preserved after removal',ba==bb and ca==cb,(before,after)); check('audit grew (history kept + removal logged)',aa>=ab)
check('comment by removed user still exists',sql("select count(*) from wp_bug_tracker_comments where content='comment by sub'")=='1')
check('row kept as removed (not deleted)',sql("select status from wp_bug_tracker_users where user_id=5")=='removed')
check('WP account still exists',sql("select count(*) from wp_users where ID=5")=='1')
check('project access revoked',sql("select count(*) from wp_bug_tracker_project_members where user_id=5")=='0')
check('their assignments cleared',sql("select count(*) from wp_bug_tracker_bugs where assignee_id=5")=='0')
st,js,_=sub.api('GET','bugs'); check('removed user blocked',st==403)
st,js,_=admin.api('GET','tracker-users'); check('removed hidden from default list','sub' not in {u['login'] for u in js['items']})
st,js,_=admin.api('GET','tracker-users',params={'status':'removed'}); check('removed visible via filter',js['total']==1)
st,js,_=admin.api('PUT',f'tracker-users/{SUB}',{'status':'active'}); check('removed user cannot be edited',st==409)
st,js,_=admin.api('POST','tracker-users',{'user_id':5,'permissions':['create_bug']}); check('re-add removed user restores access (same row)',st==201 and js['id']==SUB,(st,js))
check('re-add did not duplicate rows',sql("select count(*) from wp_bug_tracker_users where user_id=5")=='1')
# audit entries
aud=sql("select group_concat(distinct action) from wp_bug_tracker_activity where bug_id=0 and action like 'user_%' or action like 'access_%' or action='admin_assigned'")
check('user-management audit trail recorded',all(a in aud for a in ['user_added','user_deactivated','user_activated','user_removed','access_granted','access_revoked','admin_assigned']),aud)

# ---------- licensing
def lic(plan=None):
    if plan: sql(f"delete from wp_options where option_name='bug_tracker_license'; insert into wp_options (option_name,option_value,autoload) values ('bug_tracker_license','{plan}','no')")
st,js,_=admin.api('GET','tracker-users/license'); check('license status exposed',js['plan']=='free' and js['limit']==10 and js['active']>=5 and js['can_add'] is True,js)
active=js['active']
# make the limit exactly the current active count by switching to a custom plan through the filter-less route: set plan row to a tiny plan via option+mu
open('/tmp/bt-lic.php','w').close() if False else None
php=f"""<?php require '/path/to/wordpress/wp-load.php';
add_filter('bug_tracker_license_plans', function($p){{ $p['free']['max_active_users']={active}; return $p; }});
echo json_encode(BT_License::status()),'\\n';
echo json_encode(array_map(fn($r)=>is_wp_error($r)?$r->get_error_code():'ok',[BT_Users::add(4,null)])),'\\n';"""
open('/tmp/bt-lic.php','w').write(php)
out=subprocess.run(['php','/tmp/bt-lic.php'],capture_output=True,text=True).stdout
check('license limit enforced through filterable plan table',('"can_add":false' in out) and 'duplicate' in out or 'bt_license_limit' in out or 'bt_duplicate_user' in out,out)
# enforcement via REST using a must-use filter file
mu='/path/to/wordpress/wp-content/mu-plugins'
import os; os.makedirs(mu,exist_ok=True)
open(mu+'/bt-limit.php','w').write(f"<?php add_filter('bug_tracker_max_active_users', function($l){{ return {active}; }});")
st,js,_=admin.api('POST','tracker-users',{'new_user':{'username':'erin','email':'erin@example.com'}}); check('license blocks creating an active user (403)',st==403 and js['code']=='bt_license_limit',(st,js))
check('no WP account leaked when license blocks',sql("select count(*) from wp_users where user_login='erin'")=='0')
st,js,_=admin.api('PUT',f'tracker-users/{SUB}',{'status':'inactive'}); check('deactivating frees a seat',st==200)
st,js,_=admin.api('GET','tracker-users/license'); check('remaining recalculated',js['remaining']==1 and js['can_add'],js)
st,js,_=admin.api('POST','tracker-users',{'new_user':{'username':'erin','email':'erin@example.com'},'status':'inactive'}); check('inactive users do not consume seats',st==201 and js['status']=='inactive',(st,js))
st,js,_=admin.api('PUT',f'tracker-users/{js["id"]}',{'status':'active'}) if st==201 else (0,{},0); check('activating when seats remain works',st==200)
st,js,_=admin.api('PUT',f'tracker-users/{SUB}',{'status':'active'}); check('activation over limit blocked',st==403 and js['code']=='bt_license_limit',(st,js))
os.remove(mu+'/bt-limit.php')
st,js,_=admin.api('PUT',f'tracker-users/{SUB}',{'status':'active'}); check('after limit lifted activation works',st==200)
print('FAILS:',fails)
