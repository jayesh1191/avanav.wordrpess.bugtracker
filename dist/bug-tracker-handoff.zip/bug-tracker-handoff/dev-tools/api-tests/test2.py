import sys,re,urllib.parse; sys.path.insert(0,'.')
from t import *
admin=C('admin','adminpass'); alice=C('alice','pass123'); bob=C('bob','pass123')
# ---- demo data page
st,body,_=admin.raw('GET',BASE+'/wp-admin/admin.php?page=bug-tracker-settings'); html=body.decode()
check('settings page 200 w/ demo form',st==200 and 'bug_tracker_generate_demo' in html,st)
nonce=re.search(r'name="_wpnonce" value="([^"]+)"',[f for f in html.split('<form') if 'value="bug_tracker_generate_demo"' in f][0]).group(1)
def post(action,nonce,extra=None):
    d={'action':action,'_wpnonce':nonce,**(extra or {})}
    return admin.raw('POST',BASE+'/wp-admin/admin-post.php',urllib.parse.urlencode(d).encode(),{'Content-Type':'application/x-www-form-urlencoded'})
st,_,hd=post('bug_tracker_generate_demo','badnonce',{'users':3,'projects':2,'bugs':10}); check('bad nonce rejected',st==403,st)
st,_,hd=post('bug_tracker_generate_demo',nonce,{'users':4,'projects':3,'bugs':30}); check('generate redirects',st==302 and 'bt_done=generated' in hd.get('Location',''),(st,hd.get('Location')))
loc=hd.get('Location',''); check('generate counts in notice','b=30' in loc and 'p=3' in loc and 'u=4' in loc,loc)
st,js,_=admin.api('GET','dashboard'); check('dashboard has demo bugs',js['totals']['total']==30,js['totals'])
check('dashboard has activity+trend',len(js['recent_activity'])>0 and sum(t['created'] for t in js['trend'])>0)
st,js,_=admin.api('GET','projects'); check('3 demo projects',len(js)==3 and all(len(p['members'])>=2 for p in js),[len(p['members']) for p in js])
PD=js
st,js,_=admin.api('GET','users'); demo=[u for u in js['items'] if u['login'].startswith('bt_demo_')]; check('4 demo users listed',len(demo)==4,len(demo))
check('demo user email is invalid domain', all(u['email'].endswith('@example.invalid') for u in demo))
st,js,_=admin.api('GET','reports',params={'days':90}); check('reports populated',js['by_project'] and sum(c['count'] for c in js['by_status'])==30)
st,js,_=admin.api('GET','bugs',params={'per_page':100}); check('bug fields populated',all(b['title'] and b['project'] for b in js['items']) and any(b['comment_count']>0 for b in js['items']))
st,js,_=bob.api('GET','bugs'); check('real contributor not leaked demo bugs (not member)',js['total']==0,js['total'])
# non-admin cannot use tools
st,body,_=bob.raw('GET',BASE+'/wp-admin/admin.php?page=bug-tracker-settings'); check('contributor blocked from tools page',st==403 or b'bug_tracker_generate_demo' not in body,st)
st,_,hd=bob.raw('POST',BASE+'/wp-admin/admin-post.php',urllib.parse.urlencode({'action':'bug_tracker_generate_demo','_wpnonce':nonce}).encode(),{'Content-Type':'application/x-www-form-urlencoded'}); check('contributor cannot generate',st in (302,403) and 'generated' not in (hd.get('Location') or ''),st)
# generate again accumulates and tracking is separate from real data
admin.api('POST','projects',{'name':'REAL project'})
st,js,_=admin.api('POST','bugs',{'title':'REAL bug','project_id':[p for p in admin.api('GET','projects')[1] if p['name']=='REAL project'][0]['id']}); check('create real bug',st==201)
# ---- favorites
pid=PD[0]['id']
st,js,_=admin.api('PUT',f'projects/{pid}/favorite',{'favorite':True}); check('star project',st==200 and js['is_favorite'] is True,(st,js))
st,js,_=admin.api('GET','projects'); check('favorite listed for admin',[p['id'] for p in js if p['is_favorite']]==[pid])
st,js,_=alice.api('GET','projects'); check('favorites are per-user',not any(p['is_favorite'] for p in js))
st,js,_=admin.api('PUT',f'projects/{pid}/favorite',{'favorite':False}); check('unstar',js['is_favorite'] is False)
st,js,_=admin.api('PUT',f'projects/{pid}/favorite'); check('toggle without body stars',js['is_favorite'] is True)
st,js,_=admin.api('PUT',f'projects/{pid}/favorite'); check('toggle again unstars',js['is_favorite'] is False)
st,js,_=carol_ if False else (0,0,0)
st,js,_=admin.api('PUT','projects/99999/favorite',{'favorite':True}); check('favorite missing project 404',st==404)
anon=C(); st,js,_=anon.api('PUT',f'projects/{pid}/favorite',{'favorite':True}); check('anon cannot favorite',st in (401,403))
# ---- ui settings
st,s,_=admin.api('GET','settings'); check('ui defaults present',s['ui']['density']=='compact' and s['ui']['columns']['severity'] is True,s.get('ui'))
st,js,_=admin.api('PUT','settings',{'ui':{'theme':'dark','density':'comfortable','accent':'#e11d48','sidebar_collapsed':True,'default_view':'mine','group_by_status':True,'app_name':'<b>Acme</b> Bugs','columns':{'reporter':False,'created':False}}})
check('ui saved',st==200 and js['ui']['theme']=='dark' and js['ui']['accent']=='#e11d48' and js['ui']['columns']['reporter'] is False and js['ui']['columns']['severity'] is True,(st,js.get('ui')))
check('app name sanitized','<' not in js['ui']['app_name'],js['ui']['app_name'])
st,js,_=admin.api('PUT','settings',{'ui':{'theme':'neon','density':'huge','accent':'red; drop','default_view':'x'}}); check('invalid ui values ignored',js['ui']['theme']=='dark' and js['ui']['density']=='comfortable' and js['ui']['accent']=='#e11d48',js['ui'])
st,js,_=bob.api('GET','settings'); check('contributor can read ui',js['ui']['accent']=='#e11d48')
st,js,_=bob.api('PUT','settings',{'ui':{'theme':'light'}}); check('contributor cannot change ui',st==403)
admin.api('PUT','settings',{'ui':{'theme':'system','density':'compact','accent':'#4f46e5','sidebar_collapsed':False,'default_view':'all','group_by_status':False,'app_name':'','columns':{'reporter':True,'created':True}}})
# ---- remove demo
st,_,hd=post('bug_tracker_remove_demo',re.search(r'name="_wpnonce" value="([^"]+)"',admin.raw('GET',BASE+'/wp-admin/admin.php?page=bug-tracker-settings')[1].decode().split('bug_tracker_remove_demo')[1]).group(1)); check('remove redirects',st==302 and 'bt_done=removed' in hd.get('Location',''),hd.get('Location'))
st,js,_=admin.api('GET','dashboard'); check('only real bug remains',js['totals']['total']==1,js['totals'])
st,js,_=admin.api('GET','users'); check('demo users gone',not any(u['login'].startswith('bt_demo_') for u in js['items']))
st,js,_=admin.api('GET','projects'); check('only real project remains',[p['name'] for p in js]==['REAL project'],[p['name'] for p in js])
import subprocess
out=subprocess.run(['mysql','-uroot','wp','-N','-e','select (select count(*) from wp_bug_tracker_comments),(select count(*) from wp_bug_tracker_activity where project_id>0 and project_id not in (select id from wp_bug_tracker_projects)),(select count(*) from wp_bug_tracker_project_members where project_id not in (select id from wp_bug_tracker_projects))'],capture_output=True,text=True).stdout.strip()
check('no orphan rows after removal',out=='0\t0\t0',out)
print('FAILS:',fails)
