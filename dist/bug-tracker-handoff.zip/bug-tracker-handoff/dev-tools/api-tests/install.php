<?php
define('WP_INSTALLING', true);
require '/path/to/wordpress/wp-load.php';
require ABSPATH . 'wp-admin/includes/upgrade.php';
$r = wp_install('Test Site', 'admin', 'admin@example.com', true, '', 'adminpass');
echo "installed: " . $r['user_id'] . "\n";
