import sys; sys.path.insert(0,'.')
from t import *
admin=C('admin','adminpass')
st,html=admin.page
check('app page 200',st==200,st)
check('root div present','id="bug-tracker-root"' in html)
check('app.js enqueued','bug-tracker/build/app.js' in html)
check('app.css enqueued','bug-tracker/build/app.css' in html)
check('config injected',admin.cfg is not None)
check('admin caps all true',all(admin.cfg['user']['caps'].values()),admin.cfg and admin.cfg['user']['caps'])
for p in ['build/app.js','build/app.css']:
    st,_,_=admin.raw('GET',BASE+'/wp-content/plugins/bug-tracker/'+p); check('asset '+p,st==200,st)

# anonymous / no nonce
anon=C(); 
st,js,_=anon.api('GET','dashboard'); check('anon -> 401/403',st in (401,403),(st,js))
st,js,_=admin.api('GET','dashboard',nonce=False); check('logged in w/o nonce -> rejected',st in (401,403),(st,js))
st,js,hd=admin.api('GET','settings'); check('settings ok',st==200 and 'statuses' in js,(st,js)); check('refreshed nonce header',hd.get('X-BT-Nonce') is not None)
check('role matrix no longer exposed',('permissions' not in js))

# users
alice=C('alice','pass123'); bob=C('bob','pass123'); carol=C('carol','pass123'); sub=C('sub','pass123')
check('subscriber has no menu access',sub.cfg is None)
st,js,_=sub.api('GET','bugs') if sub.cfg else (0,0,0)
sub.cfg={'restUrl':BASE+'/?rest_route=/bug-tracker/v1/'}
# subscriber nonce: fetch from profile page
st,body,_=sub.raw('GET',BASE+'/bug-tracker/'); check('subscriber blocked from app page',st==403,st)
# get a nonce for the subscriber via admin-ajax
st,body,_=sub.raw('GET',BASE+'/wp-admin/admin-ajax.php?action=rest-nonce'); sub.nonce=body.decode().strip()
st,js,_=sub.api('GET','bugs'); check('subscriber API forbidden',st==403,(st,js))
st,js,_=sub.api('GET','settings'); check('subscriber settings forbidden',st==403)

# projects
st,js,_=bob.api('POST','projects',{'name':'Nope'}); check('contributor cannot create project',st==403,(st,js))
st,js,_=alice.api('POST','projects',{'name':'Alice self project'}); check('user with manage_projects creates project (auto-assigned)',st==201 and [m['user']['id'] for m in js['members']]==[alice.cfg['user']['id']],(st,js))
st,js,_=alice.api('POST','projects',{'name':'x','members':[bob.cfg['user']['id']]}); check('non-admin cannot assign members on create',st==403,(st,js))
st,js,_=admin.api('POST','projects',{'name':'Website Redesign','description':'<script>x</script>Main site','lead_id':alice.cfg['user']['id'],'members':[bob.cfg['user']['id']]}); check('admin creates project',st==201,(st,js))
P1=js['id']; check('project key auto',js['key']=='WR',js.get('key')); check('project description sanitized','<script>' not in js['description'],js['description'])
check('project members incl lead',sorted(m['user']['id'] for m in js['members'])==sorted([alice.cfg['user']['id'],bob.cfg['user']['id']]))
st,js,_=alice.api('POST','projects',{'name':''}); check('project validation',st==400 and 'name' in js['data']['fields'],(st,js))
st,js,_=admin.api('POST','projects',{'name':'Secret Project'}); P2=js['id']
st,js,_=admin.api('POST','projects',{'name':'Mobile App','key':'mob!'}); check('key sanitized',js['key']=='MOB',js); P3=js['id']

st,js,_=bob.api('GET','projects'); check('member sees only own projects',[p['id'] for p in js]==[P1],[p['id'] for p in js])
st,js,_=carol.api('GET','projects'); check('non-member sees no projects',js==[],js)
st,js,_=carol.api('GET',f'projects/{P1}'); check('non-member project 404',st==404,st)

# bugs
bugbody={'title':'Login button broken','description':'Click does nothing','steps_to_reproduce':'1. open','project_id':P1,'priority':'critical','severity':'blocker','assignee_id':bob.cfg['user']['id'],'due_date':'2030-01-31'}
st,js,_=alice.api('POST','bugs',bugbody); check('create bug',st==201,(st,js)); B1=js['id']
check('bug fields',js['priority']=='critical' and js['reporter']['name']=='Alice' and js['assignee']['name']=='Bob' and js['status']=='open',js)
st,js,_=alice.api('POST','bugs',{**bugbody,'title':''}); check('title required',st==400 and 'title' in js['data']['fields'],(st,js))
st,js,_=alice.api('POST','bugs',{**bugbody,'status':'bogus'}); check('invalid status rejected',st==400,(st,js))
st,js,_=alice.api('POST','bugs',{**bugbody,'due_date':'2030-13-45'}); check('invalid date rejected',st==400)
st,js,_=alice.api('POST','bugs',{**bugbody,'project_id':9999}); check('invalid project rejected',st==400)
st,js,_=alice.api('POST','bugs',{**bugbody,'assignee_id':carol.cfg['user']['id']}); check('assign non-member rejected',st==400 and 'assignee_id' in js['data']['fields'],(st,js))
st,js,_=bob.api('POST','bugs',{**bugbody,'title':'<b>Bob bug</b> <script>alert(1)</script>','assignee_id':0}); check('contributor member creates bug',st==201,(st,js)); B2=js['id']; check('title tags stripped','<' not in js['title'],js['title'])
st,js,_=bob.api('POST','bugs',{**bugbody,'project_id':P2,'title':'Sneaky'}); check('cannot create bug in foreign project',st==400,(st,js))
st,js,_=carol.api('GET',f'bugs/{B1}'); check('non-member bug 404',st==404,st)
st,js,_=carol.api('GET','bugs'); check('non-member list empty',js['total']==0,js['total'])
st,js,_=bob.api('GET',f'bugs/{B1}'); check('assignee/member can view',st==200 and js['can_edit'] and not js['can_delete'],(st,js.get('can_edit'),js.get('can_delete')))

# list/filter/sort/search
st,js,_=admin.api('GET','bugs'); check('list',st==200 and js['total']==2,(st,js.get('total')))
st,js,_=admin.api('GET','bugs',params={'status':'open','priority':'critical'}); check('filter',js['total']==2,js['total'])
st,js,_=admin.api('GET','bugs',params={'search':'login'}); check('search text',js['total']==1)
st,js,_=admin.api('GET','bugs',params={'search':f'#{B2}'}); check('search id',js['total']==1 and js['items'][0]['id']==B2)
st,js,_=admin.api('GET','bugs',params={'assignee_id':'unassigned'}); check('filter unassigned',js['total']==1 and js['items'][0]['id']==B2)
st,js,_=bob.api('GET','bugs',params={'assignee_id':'me'}); check('filter me',js['total']==1 and js['items'][0]['id']==B1)
for ob in ['id','title','status','priority','severity','project','assignee','reporter','created_at','updated_at','due_date']:
    st,js,_=admin.api('GET','bugs',params={'orderby':ob,'order':'asc'}); check('sort '+ob,st==200 and js['total']==2,(st,js))
st,js,_=admin.api('GET','bugs',params={'orderby':'id; DROP TABLE x','search':"' OR 1=1 --",'status':"open') OR 1=1 --"}); check('sql injection attempts safe',st==200 and js['total']==0,(st,js))
st,js,_=admin.api('GET','bugs',params={'per_page':1,'page':2,'orderby':'id','order':'asc'}); check('pagination',len(js['items'])==1 and js['total_pages']==2 and js['items'][0]['id']==B2,js)

# update + activity + notifications
st,js,_=bob.api('PUT',f'bugs/{B1}',{'status':'in_progress','severity':'major'}); check('update bug',st==200 and js['status']=='in_progress',(st,js))
st,js,_=bob.api('PUT',f'bugs/{B1}',{'status':'resolved'}); check('resolve sets resolved_at',js['resolved_at'] is not None,js)
st,js,_=bob.api('PUT',f'bugs/{B1}',{'status':'open'}); check('reopen clears resolved_at',js['resolved_at'] is None)
st,js,_=carol.api('PUT',f'bugs/{B1}',{'status':'closed'}); check('non-member update 404',st==404,st)
st,js,_=alice.api('GET',f'bugs/{B1}/activity'); check('activity logged',st==200 and any(a['field']=='status' for a in js),js)
st,js,_=alice.api('GET','notifications'); check('reporter got status/resolution notifications',st==200 and js['unread_count']>=2,js)
types={n['type'] for n in js['items']}; check('notification types',{'status','resolution'}<=types,types)
nid=js['items'][0]['id']
st,j2,_=bob.api('PUT',f'notifications/{nid}/read'); check('cannot mark others notification (no-op)',st==200)
st,js2,_=alice.api('GET','notifications',params={'unread':1}); check('still unread (not owner)',any(n['id']==nid for n in js2['items']))
st,_,_=alice.api('PUT',f'notifications/{nid}/read'); st,js2,_=alice.api('GET','notifications',params={'unread':1}); check('mark read works',not any(n['id']==nid for n in js2['items']))
st,_,_=alice.api('PUT','notifications/read-all'); st,js2,_=alice.api('GET','notifications'); check('mark all read',js2['unread_count']==0)
st,js,_=bob.api('GET','notifications'); check('assignment notification for bob',any(n['type']=='assignment' for n in js['items']),js)

# comments + mentions
st,js,_=alice.api('POST',f'bugs/{B1}/comments',{'content':'Hey @bob please look <b>now</b>'}); check('comment created',st==201 and '<b>' not in js['content'],(st,js)); C1=js['id']
st,js,_=alice.api('POST',f'bugs/{B1}/comments',{'content':'   '}); check('empty comment rejected',st==400)
st,js,_=bob.api('GET','notifications'); check('mention notification',any(n['type']=='mention' for n in js['items']),js)
st,js,_=alice.api('POST',f'bugs/{B1}/comments',{'content':'ping @carol'}); st,js,_=carol.api('GET','notifications'); check('no mention notif for user without access',js['total']==0,js)
st,js,_=carol.api('POST',f'bugs/{B1}/comments',{'content':'x'}); check('non-member cannot comment',st==404)
st,js,_=bob.api('GET',f'bugs/{B1}/comments'); check('list comments',len(js)==2 and js[0]['user']['name']=='Alice',js)
st,js,_=bob.api('DELETE',f'comments/{C1}'); check('contributor cannot delete others comment',st==403,(st,js))
st,js,_=alice.api('DELETE',f'comments/{C1}'); check('manager deletes comment',st==200)

# attachments
png=bytes.fromhex('89504e470d0a1a0a0000000d49484452000000010000000108060000001f15c4890000000d49444154789c6360000002000001e221bc330000000049454e44ae426082')
st,js,_=bob.api('POST',f'bugs/{B1}/attachments',files={'file':('shot.png',png,'image/png')}); check('upload png',st==201 and js['is_image'] and js['mime_type']=='image/png',(st,js)); A1=js['id']; url=js['url']
st,js,_=bob.api('POST',f'bugs/{B1}/attachments',files={'file':('evil.php',b'<?php echo 1;','application/x-php')}); check('php upload rejected',st==415,(st,js))
st,js,_=bob.api('POST',f'bugs/{B1}/attachments',files={'file':('evil.png',b'<?php echo 1;','image/png')}); check('fake png rejected',st==415,(st,js))
st,js,_=bob.api('POST',f'bugs/{B1}/attachments',files={'file':('a.svg',b'<svg onload=alert(1)/>','image/svg+xml')}); check('svg rejected',st==415,(st,js))
st,body,hd=bob.raw('GET',url); check('download as member',st==200 and body==png and hd.get('Content-Type')=='image/png',(st,hd.get('Content-Type')))
check('nosniff header',hd.get('X-Content-Type-Options')=='nosniff')
st,body,hd=carol.raw('GET',url); check('download as non-member blocked',st in (401,403,404),st)
st,body,hd=anon.raw('GET',url); check('download anon blocked',st in (401,403),st)
import glob
files=glob.glob('/home/user/avanav.wordrpess.bugtracker/../../tmp/x'); 
st,js,_=bob.api('GET',f'bugs/{B1}'); check('bug includes attachment',len(js['attachments'])==1)
st,body,_=bob.raw('GET',BASE+'/wp-content/uploads/bug-tracker/'); check('uploads dir listing not exposed',b'shot' not in body and b'.png' not in body,(st,body[:50]))
st,js,_=carol.api('DELETE',f'attachments/{A1}'); check('non-member cannot delete attachment',st==404)

# bulk
st,js,_=alice.api('POST','bugs/bulk',{'ids':[B1,B2],'action':'priority','value':'low'}); check('bulk priority',st==200 and sorted(js['updated'])==sorted([B1,B2]),(st,js))
st,js,_=alice.api('POST','bugs/bulk',{'ids':[B1,B2],'action':'assign','value':bob.cfg['user']['id']}); check('bulk assign',len(js['updated'])==2,js)
st,js,_=alice.api('POST','bugs/bulk',{'ids':[B1],'action':'assign','value':carol.cfg['user']['id']}); check('bulk assign invalid user reports error',st==200 and len(js['failed'])==1 or st==400,(st,js))
st,js,_=carol.api('POST','bugs/bulk',{'ids':[B1],'action':'delete'}); check('bulk delete by outsider fails',st==403 or (js and js.get('failed')),(st,js))
st,js,_=bob.api('POST','bugs/bulk',{'ids':[B1],'action':'delete'}); check('contributor lacks delete cap',(st==200 and js['failed']) or st==403,(st,js))
st,js,_=alice.api('POST','bugs/bulk',{'ids':[],'action':'status','value':'open'}); check('bulk validation',st==400)

# export
st,js,_=admin.api('GET','bugs',params={'export':1,'per_page':5000}); check('export up to 5000',st==200 and js['per_page']==5000)

# dashboard / reports / users
st,js,_=admin.api('GET','dashboard'); check('dashboard',st==200 and js['totals']['total']==2 and len(js['trend'])==30 and len(js['recent_bugs'])==2 and js['recent_activity'],js.get('totals'))
check('dashboard status chart',[c['key'] for c in js['status_chart']]==['open','in_progress','resolved','closed'])
check('trend created today',js['trend'][-1]['created']==2,js['trend'][-1])
st,js,_=bob.api('GET','dashboard'); check('dashboard scoped to member',js['totals']['total']==2 and js['totals']['assigned_to_me']==2,js['totals'])
st,js,_=carol.api('GET','dashboard'); check('dashboard empty for outsider',js['totals']['total']==0 and js['recent_activity']==[],js['totals'])
for d in [7,30,90,365,'abc']:
    st,js,_=admin.api('GET','reports',params={'days':d}); check(f'reports days={d}',st==200 and js['over_time'] and 'by_assignee' in js,(st,str(js)[:200]))
st,js,_=admin.api('GET','reports',params={'days':365}); check('reports monthly',js['granularity']=='month' and len(js['over_time'][0]['date'])==7,js['over_time'][:1])
check('reports by_project',js['by_project'][0]['label']=='Website Redesign')
st,js,_=admin.api('GET','users'); check('users list',st==200 and js['total']>=4,js)
check('admin sees emails','email' in js['items'][0])
check('no password hashes leaked','user_pass' not in json.dumps(js) and 'pass' not in {k for u in js['items'] for k in u})
st,js,_=bob.api('GET','users'); check('contributor does not see emails',all('email' not in u for u in js['items']),js['items'][0])
check('subscriber not listed',all(u['login']!='sub' for u in js['items']))
st,js,_=admin.api('GET','users',params={'search':'ali'}); check('user search',js['total']==1 and js['items'][0]['login']=='alice',js)

# settings
st,js,_=bob.api('PUT','settings',{'notifications':{'email':True}}); check('contributor cannot change settings',st==403)
st,s,_=admin.api('GET','settings')
bad=dict(s); bad['statuses']=[x for x in s['statuses'] if x['slug']!='open']
st,js,_=admin.api('PUT','settings',bad); check('cannot drop status used by bugs / missing category',st in (400,409),(st,js))
new=dict(s); new['statuses']=s['statuses']+[{'slug':'qa','label':'In QA','color':'#8b5cf6','category':'in_progress'}]
st,js,_=admin.api('PUT','settings',new); check('add status',st==200 and any(x['slug']=='qa' for x in js['statuses']),(st,js))
st,js,_=alice.api('PUT',f'bugs/{B1}',{'status':'qa'}); check('custom status usable',st==200 and js['status']=='qa',(st,js))
st,js,_=admin.api('PUT','settings',{'priorities':[{'slug':'x','label':'<b>X</b>','color':'red'}]}); check('priority replaced w/ unused slugs rejected',st==409,(st,js))
st,js,_=admin.api('PUT','settings',{'notifications':{'comment':False}}); check('toggle notifications',st==200 and js['notifications']['comment'] is False)
st,js,_=admin.api('PUT','settings',{'notifications':{'comment':True}})
# delete flows
st,js,_=bob.api('DELETE',f'bugs/{B2}'); check('reporter without delete cap forbidden',st==403,(st,js))
st,js,_=alice.api('DELETE',f'bugs/{B2}'); check('manager deletes bug',st==200)
st,js,_=alice.api('GET',f'bugs/{B2}'); check('deleted bug 404',st==404)
st,js,_=alice.api('DELETE',f'projects/{P1}'); check('project w/ bugs needs force',st==409 and js['data']['bug_count']==1,(st,js))
st,js,_=alice.api('DELETE',f'projects/{P1}',params={'force':1}); check('project force delete',st==200)
st,js,_=alice.api('GET',f'bugs/{B1}'); check('bugs removed with project',st==404)
import subprocess
out=subprocess.run(['mysql','-uroot','wp','-N','-e','select (select count(*) from wp_bug_tracker_attachments),(select count(*) from wp_bug_tracker_comments),(select count(*) from wp_bug_tracker_notifications where bug_id>0)'],capture_output=True,text=True).stdout.strip()
check('cascade cleanup rows',out=='0\t0\t0',out)
import os
d='/path/to/wordpress/wp-content/uploads/bug-tracker'
check('files removed from disk',[f for f in os.listdir(d) if f not in ('.htaccess','index.php')]==[],os.listdir(d))
check('htaccess protection written',os.path.exists(d+'/.htaccess'))
st,js,_=admin.api('DELETE',f'projects/{P3}'); check('empty project deletes w/o force',st==200)
print('\nFAILS:',fails)
