mkdir -p /run/mysqld && chown mysql:mysql /run/mysqld
(nohup mysqld_safe > /tmp/bt-mysqld.log 2>&1 &); sleep 9
cd /path/to/wordpress && (nohup php -S 127.0.0.1:8080 /path/to/scratch/router.php > /path/to/scratch/server.log 2>&1 &); sleep 2
