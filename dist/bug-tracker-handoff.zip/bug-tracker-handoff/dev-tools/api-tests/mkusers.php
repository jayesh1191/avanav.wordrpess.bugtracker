<?php
require '/path/to/wordpress/wp-load.php';
foreach ([['alice','bug_tracker_manager'],['bob','bug_tracker_contributor'],['carol','bug_tracker_contributor'],['sub','subscriber']] as [$l,$r]) {
  if (!username_exists($l)) { wp_insert_user(['user_login'=>$l,'user_pass'=>'pass123','user_email'=>"$l@example.com",'role'=>$r,'display_name'=>ucfirst($l)]); }
}
echo "ok\n";
