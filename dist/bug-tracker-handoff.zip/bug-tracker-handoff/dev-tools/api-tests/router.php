<?php
$p = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$f = $_SERVER['DOCUMENT_ROOT'] . $p;
if ($p !== '/' && is_file($f)) return false;
if (is_dir($f) && is_file($f.'/index.php')) { chdir($f); require $f.'/index.php'; return true; }
$_SERVER['SCRIPT_NAME']='/index.php'; require $_SERVER['DOCUMENT_ROOT'].'/index.php';
