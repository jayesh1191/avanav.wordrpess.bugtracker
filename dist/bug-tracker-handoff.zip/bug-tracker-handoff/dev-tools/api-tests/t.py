import urllib.request, urllib.parse, http.cookiejar, json, re, sys, uuid, io
BASE='http://127.0.0.1:8080'
class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,*a,**k): return None
class C:
    def __init__(s, user=None, pw=None):
        s.cj=http.cookiejar.CookieJar()
        s.op=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(s.cj), NoRedirect())
        s.nonce=None; s.cfg=None
        if user: s.login(user,pw)
    def raw(s, method, url, data=None, headers=None):
        req=urllib.request.Request(url, data=data, method=method, headers=headers or {})
        try:
            r=s.op.open(req); return r.status, r.read(), r.headers
        except urllib.error.HTTPError as e:
            return e.code, e.read(), e.headers
    def login(s,u,p):
        s.raw('GET',BASE+'/wp-login.php')
        s.cj.set_cookie(http.cookiejar.Cookie(0,'wordpress_test_cookie','WP%20Cookie%20check',None,False,'127.0.0.1',False,False,'/',True,False,None,False,None,None,{}))
        d=urllib.parse.urlencode({'log':u,'pwd':p,'wp-submit':'Log In','redirect_to':BASE+'/bug-tracker/','testcookie':'1'}).encode()
        st,_,_=s.raw('POST',BASE+'/wp-login.php',d,{'Content-Type':'application/x-www-form-urlencoded'})
        assert st==302,(u,st)
        st,body,_=s.raw('GET',BASE+'/bug-tracker/')
        s.page=(st,body.decode())
        m=re.search(r'window\.BugTrackerConfig = (\{.*?\});\n?',s.page[1],re.S)
        if m: s.cfg=json.loads(m.group(1)); s.nonce=s.cfg['nonce']
    def api(s, method, path, body=None, params=None, nonce=True, files=None):
        url=s.cfg['restUrl'] if s.cfg else BASE+'/?rest_route=/bug-tracker/v1/'
        url=url+path
        if params: url+=('&' if '?' in url else '?')+urllib.parse.urlencode(params)
        h={'Accept':'application/json'}
        if nonce and s.nonce: h['X-WP-Nonce']=s.nonce
        data=None
        if files:
            b=uuid.uuid4().hex; buf=io.BytesIO()
            for name,(fn,content,ct) in files.items():
                buf.write(f'--{b}\r\nContent-Disposition: form-data; name="{name}"; filename="{fn}"\r\nContent-Type: {ct}\r\n\r\n'.encode()); buf.write(content); buf.write(b'\r\n')
            buf.write(f'--{b}--\r\n'.encode()); data=buf.getvalue(); h['Content-Type']='multipart/form-data; boundary='+b
        elif body is not None:
            data=json.dumps(body).encode(); h['Content-Type']='application/json'
        st,raw,hd=s.raw(method,url,data,h)
        try: js=json.loads(raw)
        except Exception: js=raw
        return st,js,hd
fails=[]
def check(name,cond,extra=''):
    print(('PASS ' if cond else 'FAIL ')+name+(' '+str(extra) if (extra and not cond) else ''))
    if not cond: fails.append(name)
