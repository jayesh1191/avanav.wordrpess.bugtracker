<?php
require '/path/to/wordpress/wp-load.php';
require_once ABSPATH . 'wp-admin/includes/plugin.php';
$r = activate_plugin('bug-tracker/bug-tracker.php');
echo is_wp_error($r) ? 'ERROR: '.$r->get_error_message() : 'activated', "\n";
echo 'active: ', var_export(is_plugin_active('bug-tracker/bug-tracker.php'), true), "\n";
