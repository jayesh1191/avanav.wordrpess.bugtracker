import sys; sys.path.insert(0,'.')
from t import *
import random
admin=C('admin','adminpass'); alice=C('alice','pass123'); bob=C('bob','pass123')
a,b=alice.cfg['user']['id'],bob.cfg['user']['id']
_,p1,_=admin.api('POST','projects',{'name':'Website Redesign','description':'Marketing site rebuild','lead_id':a,'members':[a,b],'color':'#6366f1'})
_,p2,_=admin.api('POST','projects',{'name':'Mobile App','description':'iOS and Android','lead_id':b,'members':[a,b],'color':'#10b981'})
random.seed(4)
titles=['Login button unresponsive','Checkout total miscalculated','Image upload fails on Safari','Dark mode flashes on load','Search returns stale results','Password reset email delayed','Layout breaks under 360px','Crash when rotating device','Typo on pricing page','Slow dashboard query']
for i,t in enumerate(titles):
    st,js,_=admin.api('POST','bugs',{'title':t,'description':'Details for '+t,'project_id':(p1 if i%2==0 else p2)['id'],'priority':random.choice(['low','medium','high','critical']),'severity':random.choice(['trivial','minor','major','blocker']),'assignee_id':random.choice([0,a,b]),'status':random.choice(['open','open','in_progress','resolved','closed'])})
    assert st==201,js
alice.api('POST','bugs/1/comments',{'content':'Looking into it @bob'})
print('seeded')
