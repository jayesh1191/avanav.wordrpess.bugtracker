<?php
require '/path/to/wordpress/wp-load.php';
require_once ABSPATH.'wp-admin/includes/plugin.php';
deactivate_plugins('bug-tracker/bug-tracker.php'); activate_plugin('bug-tracker/bug-tracker.php');
update_option('permalink_structure','/%postname%/'); flush_rewrite_rules();
echo BT_App_Page::url(),"\n";
