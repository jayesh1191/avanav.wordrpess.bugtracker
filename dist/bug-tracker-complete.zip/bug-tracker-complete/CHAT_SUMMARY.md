# Summary of the build conversation

Project: **WordPress Bug Tracker plugin with a 100 % React frontend**, built incrementally in one session (repo `jayesh1191/avanav.wordrpess.bugtracker`, branch `claude/kind-fermi-7wdnux`). Every step was verified against a real WordPress 7.1.2 + MariaDB 10.11 + PHP 8.3 stack, not mocks.

## Timeline of requests and what was delivered

### 1. Initial brief – complete bug-tracker plugin, React-only UI
*Request:* standalone WordPress plugin; PHP only for REST/DB/auth/permissions; UI entirely React (TypeScript, Vite, React Router, Tailwind, shadcn/ui, Lucide, React Hook Form + Zod, TanStack Query, Recharts); custom tables via `dbDelta`; REST API under `/wp-json/bug-tracker/v1/`; dashboard, bugs table, create/edit, detail, projects, users, reports, notifications, settings; capabilities; dark mode; no mock data; installable and activatable.

*Delivered:* the plugin in `bug-tracker/` with 7 custom tables (projects, project_members, bugs, comments, attachments, activity, notifications), ~35 REST endpoints, all CRUD, attachments stored outside direct web access and served through an authenticated endpoint, notifications with @mentions, configurable statuses/priorities/severities, CSV export, bulk actions, charts, demo-free (real data only), compiled assets committed in `build/`.
*Verification:* activation, tables, assets, REST, permissions, CRUD, attachments, assignment, no console errors, responsive – checked with ~130 automated API checks and Playwright browser runs.

### 2. "Make it in its own URL, not wp-admin"
The app now lives at **`/bug-tracker/`** (rewrite rule; `/?bug_tracker_app=1` with plain permalinks) as a standalone HTML shell: login required (redirects to wp-login and back), noindex, no admin bar. The wp-admin menu item just links to it. Admin-bar layout offsets were removed from the UI.

### 3. "dist?"
Added `dist/bug-tracker.zip` (installable build) and an `npm run package` script that regenerates it.

### 4. "It doesn't resemble a bug tracker – too roomy" → full UI redesign
Rebuilt the interface as a compact, Linear/Jira-style issue tracker:
* new design system (neutral zinc, one indigo accent, compact type scale, semantic state colours, proper dark theme);
* single 44 px top bar (breadcrumbs and page actions portalled in), slim sidebar with project shortcuts;
* dense list view: Jira-style keys (`WR-12`), status/priority glyphs, quick-view tabs, one-row filter chips (multi-select), group-by-status, sortable columns, bulk bar, mobile two-line rows;
* bug page: inline-editable properties panel + single comments/activity timeline;
* compact dashboard, projects list, forms; shortcuts `C` and `/`.

### 5. Burger/collapse, starred projects, UI settings, demo data (+ "refetch when opening an issue")
* Burger button collapses the sidebar to icons on desktop (remembered per user).
* **Per-user starred projects** (star/unstar; "Starred" sidebar section only when something is starred).
* **Settings → Appearance** (app name, default theme, density, accent colour, default bugs view, grouping, sidebar default, visible columns) – admin defaults, per-user overrides for theme/sidebar.
* **wp-admin → Bug Tracker → Settings & tools → Demo data**: generates tracked users/projects/bugs/comments/activity and removes exactly what it created.
* Opening a bug now always refetches the bug, comments and activity (no stale cache).

### 6. "Once a project is starred, don't remove it from the project list"
Sidebar now keeps every project in *Projects* and additionally lists starred ones under *Starred* (small star marker in the main list).

### 7. Custom user management (v1.1.0) – the last big change
Requirements: no WordPress roles/capabilities for access; a single **Bug Tracker Admin** assigned by the site administrator; add existing/create new users; activate/deactivate/remove without losing history; accordion user list showing project access; strict project-level enforcement; licence-ready; secure and non-destructive.

Delivered:
* new `bug_tracker_users` table (status `active/inactive/removed`, per-user permission flags); `BT_Users`, `BT_Permissions` (rewritten, no WP caps), `BT_License` (provider seam, filterable plans, default Free = 10 active users), `BT_Users_Controller` (`/tracker-users/*`, admin only);
* secure first-run flow (activating site admin becomes Bug Tracker Admin; otherwise app locks with a "setup required" screen until a site admin assigns one in wp-admin);
* accordion Users screen (search, status tabs, pagination, per-project assign/remove with role, permissions, add existing / create new with validation, edit, activate/deactivate, soft-remove/restore);
* project access strictly by explicit assignment, enforced in every query; assignee directory limited to collaborators; project lead/members editable only by the Bug Tracker Admin;
* idempotent, non-destructive **migration** from the old role-based model (permissions derived from old capabilities; effective access preserved; leads/creators made explicit); old roles left in the DB, unused;
* audit entries for user-management actions in the existing activity table; role-matrix settings tab removed.

### 8. This request – hand-off zip
Packaged source, full git history (bundle), installable plugin zip, test/dev scripts, this summary and migration instructions.

## Key design decisions
| Decision | Why |
|---|---|
| WordPress = auth only; access in plugin table | Explicit requirement; makes licensing and per-project control independent of WP roles |
| Soft-remove users | Preserve bugs, comments and audit history; allow restore |
| Hash router, single rewrite rule | Works on any host; deep links survive reloads |
| Tailwind preflight off + everything scoped | Cannot be broken by (or break) other CSS; Radix portals mounted inside the root |
| Compiled `build/` committed | Plugin installs without Node on the server |
| Attachments via authenticated REST download | Files never directly web-accessible; SVG/PHP types rejected, content-sniffed |
| Hidden resources return 404 | Doesn't reveal that a bug/project exists |
| Profile edits blocked for WP accounts with admin rights | Prevents account takeover through the tracker's edit form |

## Bugs found by testing and fixed along the way
* Dialogs mis-positioned: Tailwind `--tw-*` defaults were missing with preflight off → re-added, scoped to the root via PostCSS.
* Single-row delete asked for confirmation twice.
* Bugs page scrolled sideways on mobile (Radix hidden checkbox inputs escaping the scroll container).
* Detail page showed "Comments (0)" with comments present; dashboard overflowed on mobile (grid `min-w-0`).
* Stray 404 refetch after deleting a bug/project.
* Duplicate "Search bugs" accessible name (top bar vs page).
* Translation text-domain loaded too early during the upgrade/migration (PHP 6.7+ notice).
* Test-harness issues (stale state, ambiguous selectors, wrong nonce) were fixed in the tests, not by weakening checks.

## Test results at hand-off
* API suites: core **134**, demo/favourites/UI-settings **29**, user management/permissions/licence **122** – all pass.
* Playwright flows (bugs CRUD, bulk, export, projects, settings, sidebar/stars/appearance, refetch-on-open, user management, non-admin views, mobile) – all pass; no horizontal scroll at 390 px.
* Debug log: no plugin notices/warnings after the fixes (only WordPress.org network warnings from the offline sandbox).

## Known limitations / things to decide
* Project access is now stricter than 1.0.0: lead/creator/reporter/assignee no longer grant access by themselves (leads/creators were migrated to explicit assignments).
* Default licence is Free = 10 active users – a placeholder, change in `BT_License_Local_Provider::plans()` or via the filter.
* No payment/licence-key code, no multisite handling, English-only React strings.
* Bundle ≈ 1 MB (Recharts); new-bug form is a page rather than a drawer.
* Emails (assignment/mention notifications, new-user password link) rely on the site's `wp_mail` setup; they could not be exercised in the offline sandbox.

## Commit history (in `bug-tracker-full-history.bundle`)
```
452c489 Add Bug Tracker WordPress plugin with a full React frontend
e895f06 Serve the app on its own front-end URL (/bug-tracker/) instead of wp-admin
2fe677c Add dist/bug-tracker.zip installable build
acbaa0b Redesign UI as a compact issue tracker (Linear/Jira-style)
2ccc1e7 Collapsible sidebar, starred projects, UI settings, demo data generator
3fbad51 Keep starred projects in the sidebar Projects list
e3e59a1 Add plugin-owned user management, Bug Tracker Admin and licence seam (v1.1.0)
3b49de8 Add hand-off package (source, history bundle, plugin zip, docs, dev tools)
ea07ec1 Add CLAUDE.md project context; drop superseded hand-off zip
```
